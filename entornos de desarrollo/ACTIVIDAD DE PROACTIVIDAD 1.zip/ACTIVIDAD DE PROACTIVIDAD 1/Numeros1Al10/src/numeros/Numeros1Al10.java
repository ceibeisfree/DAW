package numeros;

// Imprimir por pantalla los 10 primeros números en JAVA.

public class Numeros1Al10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i;
        for(i = 1; i <= 10; i++){
            System.out.println(i);
        }    

	}

}
