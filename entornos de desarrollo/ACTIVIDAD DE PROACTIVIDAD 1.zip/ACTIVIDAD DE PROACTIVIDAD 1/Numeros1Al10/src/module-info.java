/**
 * 
 */
/**
 * 
 */
module Numeros1Al10 {
}